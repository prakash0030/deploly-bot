const { EmbedBuilder } = require('discord.js');

class BotEmbedBuilder {
    static buildResultEmbed(data) {
        if (!data.success) {
            return new EmbedBuilder()
                .setTitle('❌ Error')
                .setDescription(data.message || 'Unknown Error')
                .setColor(0xFF0000);
        }

        const hypixelStats = data.hypixel || {};
        const donutStatus = data.donut || {};
        const hypixelBan = data.hypixel_ban || {};

        const isHypixelUnbanned = hypixelBan.status === 'Clean';
        const isDonutUnbanned = donutStatus.status === 'Unbanned';
        const isHypixelBanned = hypixelBan.status === 'Banned';
        const isDonutBanned = donutStatus.status === 'Banned';

        let color = 0x808080; // Default Gray

        if (isDonutUnbanned) {
            color = 0x00FF00; // Green for Donut Unbanned
        } else if (isHypixelUnbanned || (hypixelStats.rank && hypixelStats.rank !== 'None')) {
            color = 0xFFFF00; // Yellow for Hypixel (Unbanned or Ranked)
        } else if (isDonutBanned || isHypixelBanned) {
            color = 0xFF0000; // Red for Banned
        }

        const embed = new EmbedBuilder()
            .setColor(color)
            .setAuthor({
                name: 'Warv Checker',
                iconURL: 'https://i.postimg.cc/Xvh32RQr/IMG-20260129-110839.jpg'
            })
            .setTimestamp()
            .setFooter({
                text: 'Warv Checker • Made by Warv and Rahul',
                iconURL: 'https://i.postimg.cc/Xvh32RQr/IMG-20260129-110839.jpg'
            });

        embed.addFields(
            { name: '<:mmail:1430291754459856946> Eᴍᴀɪʟ', value: `||\`${data.email}\`||`, inline: true },
            { name: '<:keiy:1430291766590050304> Pᴀѕѕᴡᴏʀᴅ', value: `||\`${data.password}\`||`, inline: true },
            { name: '<:name_tag:1430291758893498460> Uѕᴇʀɴᴀᴍᴇ', value: `\`${data.username || 'N/A'}\``, inline: true },
            { name: '<:brok:1430291739272417353> Aᴄᴄᴏᴜɴᴛ Tʏᴘᴇ', value: `\`${data.type}\``, inline: true }
        );

        if (hypixelStats.level) embed.addFields({ name: '<:hypixel:1430291770012340246> Hʏᴘɪxᴇʟ Lᴇᴠᴇʟ', value: `${hypixelStats.level}`, inline: true });
        if (hypixelStats.rank) embed.addFields({ name: '<:hypixel:1430291770012340246> Hʏᴘɪxᴇʟ Rᴀɴᴋ', value: `${hypixelStats.rank}`, inline: true });
        if (hypixelStats.first_login) embed.addFields({ name: '<:hypixel:1430291770012340246> Fɪʀѕᴛ Lᴏɢɪɴ', value: `${hypixelStats.first_login}`, inline: true });
        if (hypixelStats.last_login) embed.addFields({ name: '<:hypixel:1430291770012340246> Lᴀѕᴛ Lᴏɢɪɴ', value: `${hypixelStats.last_login}`, inline: true });
        if (hypixelStats.bw_stars) embed.addFields({ name: '<:hypixel:1430291770012340246> Bᴇᴅᴡᴀʀѕ Sᴛᴀʀѕ', value: `${hypixelStats.bw_stars}`, inline: true });
        if (hypixelStats.sb_coins) embed.addFields({ name: '<:hypixel:1430291770012340246> Sᴋʏʙʟᴏᴄᴋ Cᴏɪɴѕ', value: `${hypixelStats.sb_coins}`, inline: true });

        if (hypixelBan.status) {
            const hStatus = hypixelBan.status || 'Unknown';
            let hEmoji = '❓';
            if (hStatus === 'Clean') hEmoji = '<a:unbanned:1430296212015419484>';
            else if (hStatus === 'Banned') hEmoji = '<a:banned:1430293755155448014>';

            let hVal = `${hEmoji} ${hStatus}`;
            if (hypixelBan.reason) {
                hVal += `\nReason: ${hypixelBan.reason}`;
            }
            embed.addFields({ name: '<:hypixel:1430291770012340246> Hʏᴘɪxᴇʟ Bᴀɴ', value: hVal, inline: true });
        }

        if (data.capes && data.capes.length > 0) {
            embed.addFields({ name: '<:cape:1430291744934592612> Cᴀᴘᴇѕ', value: data.capes.join(', '), inline: true });
        }

        // Donut Stats
        const dStatus = donutStatus.status || 'Unknown';
        let dEmoji = '❓';
        if (dStatus === 'Unbanned') dEmoji = '<a:unbanned:1430296212015419484>';
        else if (dStatus === 'Banned') dEmoji = '<a:banned:1430293755155448014>';

        embed.addFields({ name: '<a:donut:1430291763641188372> Dᴏɴᴜᴛ Sᴛᴀᴛᴜѕ', value: `${dEmoji} ${dStatus}`, inline: true });

        if (donutStatus.money) embed.addFields({ name: '<a:donut:1430291763641188372> Mᴏɴᴇʏ', value: `${donutStatus.money}`, inline: true });
        if (donutStatus.playtime) embed.addFields({ name: '<a:donut:1430291763641188372> Pʟᴀʏᴛɪᴍᴇ', value: `${donutStatus.playtime}`, inline: true });
        if (donutStatus.reason) {
            embed.addFields({ name: '<a:donut:1430291763641188372> Bᴀɴ Rᴇᴀѕᴏɴ', value: `${donutStatus.reason}`, inline: true });
        }

        embed.addFields({
            name: '<:combo:1430291747912548454> Cᴏᴍʙᴏ',
            value: `||\`\`\`${data.email}:${data.password}\`\`\`||`,
            inline: false
        });

        if (data.username && data.username !== 'N/A') {
            embed.setThumbnail(`https://mc-heads.net/body/${data.username}`);
        } else {
            embed.setThumbnail('https://mc-heads.net/body/steve');
        }

        return embed;
    }

    static buildStatusEmbed(stats) {
        const embed = new EmbedBuilder()
            .setTitle('<a:loading:1434520216028577885> Warv Checker Live Status')
            .setColor(0x00FFFF)
            .setTimestamp()
            .setFooter({
                text: 'Warv Checker • Made by Warv and Rahul',
                iconURL: 'https://i.postimg.cc/Xvh32RQr/IMG-20260129-110839.jpg'
            });

        embed.addFields(
            { name: '<a:rght:1434491384370434168> Checked', value: `\`${stats.checked}/${stats.total}\``, inline: true },
            { name: '<:combo:1430291747912548454> Hits', value: `\`${stats.hits}\``, inline: true },
            { name: '<a:unbanned:1430296212015419484> Unbanned', value: `\`${stats.unbanned}\``, inline: true },
            { name: '<a:banned:1430293755155448014> Banned', value: `\`${stats.banned}\``, inline: true },
            { name: '<:brok:1430291739272417353> Free/Bad', value: `\`${stats.bad}\``, inline: true }
        );

        const progressRaw = stats.total > 0 ? stats.checked / stats.total : 0;
        const progressInt = Math.floor(progressRaw * 10);
        const bar = '🟩'.repeat(progressInt) + '⬜'.repeat(10 - progressInt);
        const percentage = Math.floor(progressRaw * 100);

        embed.addFields({ name: 'Progress', value: `\`${bar}\` ${percentage}%`, inline: false });

        return embed;
    }
}

module.exports = BotEmbedBuilder;
