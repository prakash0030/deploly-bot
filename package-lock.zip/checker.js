const axios = require('axios');
const cheerio = require('cheerio');
const mineflayer = require('mineflayer');
const { v4: uuidv4 } = require('uuid');
const { URLSearchParams } = require('url');
const https = require('https');

const httpsAgent = new https.Agent({
    rejectUnauthorized: false
});

class WarvChecker {
    constructor() {
        this.sFTTag_url = "https://login.live.com/oauth20_authorize.srf?client_id=00000000402B5328&redirect_uri=https://login.live.com/oauth20_desktop.srf&scope=service::user.auth.xboxlive.com::MBI_SSL&display=touch&response_type=token&locale=en";
        this.cookies = new Map();
    }

    getCookieHeader() {
        return Array.from(this.cookies.entries()).map(([k, v]) => `${k}=${v}`).join('; ');
    }

    updateCookies(headers) {
        if (headers['set-cookie']) {
            headers['set-cookie'].forEach(cookieStr => {
                const parts = cookieStr.split(';')[0].split('=');
                if (parts.length >= 2) {
                    this.cookies.set(parts[0].trim(), parts.slice(1).join('=').trim());
                }
            });
        }
    }

    async getUrlPostSFTTag() {
        try {
            const response = await axios.get(this.sFTTag_url, {
                timeout: 15000,
                httpsAgent,
                headers: {
                    'Cookie': this.getCookieHeader(),
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                }
            });
            this.updateCookies(response.headers);
            const text = response.data;
            let sFTTag = null;
            let urlPost = null;

            const sFTTagMatch = text.match(/value=\\"(.+?)\\"/) || text.match(/value="(.+?)"/);
            if (sFTTagMatch) sFTTag = sFTTagMatch[1];

            const urlPostMatch = text.match(/"urlPost":"(.+?)"/) || text.match(/urlPost:'(.+?)'/);
            if (urlPostMatch) urlPost = urlPostMatch[1];

            return { urlPost, sFTTag };
        } catch (error) {
            return { urlPost: null, sFTTag: null };
        }
    }

    async getXboxRps(email, password, urlPost, sFTTag) {
        try {
            const params = new URLSearchParams();
            params.append('login', email);
            params.append('loginfmt', email);
            params.append('passwd', password);
            params.append('PPFT', sFTTag);

            let currentUrl = urlPost;
            let currentMethod = 'POST';
            let currentData = params;
            let redirectCount = 0;

            while (redirectCount < 10) {
                console.log(`[Checker] [RPS] ${currentMethod} to ${currentUrl}`);
                const response = await axios({
                    method: currentMethod,
                    url: currentUrl,
                    data: currentMethod === 'POST' ? currentData : null,
                    httpsAgent,
                    headers: {
                        'Content-Type': currentMethod === 'POST' ? 'application/x-www-form-urlencoded' : undefined,
                        'Cookie': this.getCookieHeader(),
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                    },
                    timeout: 20000,
                    maxRedirects: 0,
                    validateStatus: null
                });

                this.updateCookies(response.headers);

                const location = response.headers.location;
                if (location) {
                    const nextUrl = location.startsWith('http') ? location : new URL(location, currentUrl).href;
                    console.log(`[Checker] [RPS] Redirected (Status ${response.status}) to: ${nextUrl}`);

                    if (nextUrl.includes('#')) {
                        const fragment = nextUrl.split('#')[1];
                        const tokenParams = new URLSearchParams(fragment);
                        const token = tokenParams.get('access_token');
                        if (token) {
                            console.log("[Checker] Xbox RPS Access Token found in fragment");
                            return { token, error: null };
                        }
                    }

                    currentUrl = nextUrl;
                    currentMethod = 'GET'; // After first POST, subsequent redirects are usually GET
                    currentData = null;
                    redirectCount++;
                    continue;
                }

                const responseText = response.data;
                if (typeof responseText === 'string') {
                    if (responseText.includes('cancel?mkt=')) {
                        console.log("[Checker] Login cancelled");
                        return { token: null, error: "Login Cancelled/Intersected" };
                    }

                    if (/recover\?mkt|account\.live\.com\/identity\/confirm\?mkt|Email\/Confirm\?mkt|\/Abuse\?mkt=/.test(responseText)) {
                        console.log("[Checker] 2FA/Recovery required");
                        return { token: "2FA", error: "2FA Required" };
                    }

                    if (responseText.includes("Sign in to") || responseText.includes("Enter password")) {
                        console.log("[Checker] Invalid Credentials detected");
                        return { token: null, error: "Invalid Credentials" };
                    }
                }

                console.error("[Checker] Ended without redirect or token, status:", response.status);
                return { token: null, error: "Unknown Login Response" };
            }

            return { token: null, error: "Too many redirects" };
        } catch (error) {
            console.error(`[Checker] Xbox RPS Error: ${error.message}`);
            return { token: null, error: `Login Request Error: ${error.message}` };
        }
    }

    async getMcToken(uhs, xstsToken) {
        for (let i = 0; i < 3; i++) {
            try {
                const response = await axios.post('https://api.minecraftservices.com/authentication/login_with_xbox', {
                    identityToken: `XBL3.0 x=${uhs};${xstsToken}`
                }, {
                    timeout: 15000,
                    httpsAgent,
                    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' }
                });

                if (response.status === 200) {
                    return response.data.access_token;
                }
            } catch (error) {
                console.error(`[Checker] MC Token Auth Error (Attempt ${i + 1}): ${error.message}`);
            }
            if (i < 2) await new Promise(r => setTimeout(r, 1000));
        }
        return null;
    }

    async checkOwnership(token) {
        for (let i = 0; i < 3; i++) {
            try {
                console.log(`[Checker] Checking MC Ownership (Attempt ${i + 1})`);
                const response = await axios.get('https://api.minecraftservices.com/entitlements/mcstore', {
                    httpsAgent,
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                    },
                    timeout: 10000
                });
                console.log(`[Checker] Ownership Status: ${response.status}`);

                if (response.status === 200) {
                    const items = response.data.items || [];
                    console.log(`[Checker] Ownership items found: ${items.length}`);
                    let hasNormal = false;
                    let hasGpPc = false;
                    let hasGpUlt = false;

                    for (const item of items) {
                        const name = item.name;
                        const source = item.source;
                        if ((name === "game_minecraft" || name === "product_minecraft") && (source === "PURCHASE" || source === "MC_PURCHASE")) {
                            hasNormal = true;
                        }
                        if (name === "product_game_pass_pc") hasGpPc = true;
                        if (name === "product_game_pass_ultimate") hasGpUlt = true;
                    }

                    if (hasNormal && hasGpPc) return "Normal Minecraft (with Game Pass)";
                    if (hasNormal && hasGpUlt) return "Normal Minecraft (with Game Pass Ultimate)";
                    if (hasNormal) return "Normal Minecraft";
                    if (hasGpUlt) return "Xbox Game Pass Ultimate";
                    if (hasGpPc) return "Xbox Game Pass (PC)";

                    const others = [];
                    const text = JSON.stringify(response.data);
                    if (text.includes('product_minecraft_bedrock')) others.push("Minecraft Bedrock");
                    if (text.includes('product_legends')) others.push("Minecraft Legends");
                    if (text.includes('product_dungeons')) others.push('Minecraft Dungeons');
                    if (others.length > 0) return `Other (${others.join(', ')})`;

                    return "No Minecraft Product";
                }
            } catch (error) {
                console.error(`[Checker] Ownership Error (Attempt ${i + 1}): ${error.message}`);
            }
            if (i < 2) await new Promise(r => setTimeout(r, 1000));
        }
        return "Error Checking Ownership";
    }

    async getProfile(token) {
        for (let i = 0; i < 3; i++) {
            try {
                const response = await axios.get('https://api.minecraftservices.com/minecraft/profile', {
                    httpsAgent,
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                    },
                    timeout: 10000
                });

                if (response.status === 200) {
                    const data = response.data;
                    return {
                        id: data.id,
                        name: data.name,
                        capes: data.capes || []
                    };
                }
            } catch (error) {
                console.error(`[Checker] Profile Fetch Error (Attempt ${i + 1}): ${error.message}`);
            }
            if (i < 2) await new Promise(r => setTimeout(r, 1000));
        }
        return { id: null, name: null, capes: [] };
    }

    async checkHypixelStats(username) {
        const stats = {};
        try {
            const headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0' };
            const response = await axios.get(`https://plancke.io/hypixel/player/stats/${username}`, {
                httpsAgent,
                headers
            });
            const $ = cheerio.load(response.data);

            const text = response.data;
            const levelMatch = text.match(/(?<=Level:<\/b> ).+?(?=<br\/><b>)/);
            if (levelMatch) stats.level = levelMatch[0].trim();

            const firstLoginMatch = text.match(/(?<=<b>First login: <\/b>).+?(?=<br\/><b>)/);
            if (firstLoginMatch) stats.first_login = firstLoginMatch[0].trim();

            const lastLoginMatch = text.match(/(?<=<b>Last login: <\/b>).+?((?=<br\/>)|(?=<\/b>))/);
            if (lastLoginMatch) stats.last_login = lastLoginMatch[0].trim();

            const bwStarsMatch = text.match(/(?<=<li><b>Level:<\/b> ).+?(?=<\/li>)/);
            if (bwStarsMatch) stats.bw_stars = bwStarsMatch[0].trim();

            const rankMatch = text.match(/<b>Rank:<\/b>\s*([^<]+)/);
            if (rankMatch) stats.rank = rankMatch[1].trim();

            const karmaMatch = text.match(/<b>Karma:<\/b>\s*([^<]+)/);
            if (karmaMatch) stats.karma = karmaMatch[1].trim();

        } catch (error) { }

        try {
            const response = await axios.get(`https://sky.shiiyu.moe/stats/${username}`, { httpsAgent });
            const networthMatch = response.data.match(/(?<= Networth: ).+?(?=\n)/);
            if (networthMatch) stats.sb_coins = networthMatch[0].trim();
        } catch (error) { }

        return stats;
    }

    async checkMineflayerBan(host, username, token, uuidStr) {
        return new Promise((resolve) => {
            const options = {
                host: host,
                port: 25565,
                username: username,
                session: {
                    accessToken: token,
                    selectedProfile: {
                        id: uuidStr,
                        name: username
                    }
                },
                version: host === 'hypixel.net' ? '1.8.9' : '1.20.2',
                auth: 'mojang',
                skipValidation: true
            };

            // Using mineflayer for actual connection check
            const bot = mineflayer.createBot(options);
            const status = { status: "Unknown", reason: null };
            let resolved = false;

            const cleanup = () => {
                if (bot) {
                    try { bot.end(); } catch (e) { }
                }
            };

            const finish = (res) => {
                if (resolved) return;
                resolved = true;
                cleanup();
                resolve(res);
            };

            bot.once('spawn', () => {
                status.status = host === 'hypixel.net' ? 'Clean' : 'Unbanned';
                finish(status);
            });

            bot.on('error', (err) => {
                status.status = "Unknown";
                status.reason = `Connection Error: ${err.message}`;
                finish(status);
            });

            bot.on('kicked', (reason) => {
                status.status = "Banned";
                try {
                    const kickReason = JSON.parse(reason);
                    if (kickReason.text) status.reason = kickReason.text;
                    else if (kickReason.extra) status.reason = kickReason.extra.map(e => e.text).join(' ');
                    else status.reason = reason.substring(0, 100);
                } catch (e) {
                    status.reason = reason.replace(/§./g, '').substring(0, 100);
                }

                if (status.reason.includes("Suspicious activity")) {
                    const banIdMatch = status.reason.match(/Ban ID: ([A-Z0-9]+)/);
                    if (banIdMatch) status.reason = `Suspicious activity. Ban ID: ${banIdMatch[1]}`;
                }

                finish(status);
            });

            // Timeout after 8 seconds
            setTimeout(() => {
                if (!resolved) {
                    status.status = "Unknown";
                    status.reason = "Connection Timeout";
                    finish(status);
                }
            }, 8000);
        });
    }

    async checkDonutStats(username, token, uuidStr) {
        // Since we need to read chat, we need a slightly longer connection or a special handler
        return new Promise((resolve) => {
            const options = {
                host: 'donutsmp.net',
                port: 25565,
                username: username,
                session: { accessToken: token, selectedProfile: { id: uuidStr, name: username } },
                version: '1.20.2',
                auth: 'mojang',
                skipValidation: true
            };

            const bot = mineflayer.createBot(options);
            const status = { status: "Unknown", money: null, playtime: null, shards: null, rank: null, reason: null };
            let resolved = false;

            const finish = (res) => {
                if (resolved) return;
                resolved = true;
                try { bot.end(); } catch (e) { }
                resolve(res);
            };

            bot.once('spawn', () => {
                status.status = "Unbanned";
                // Let it stay for a while to catch chat messages if any
                setTimeout(() => finish(status), 5000);
            });

            bot.on('messagestr', (message) => {
                const clean = message.replace(/§./g, '');

                const moneyMatch = clean.match(/(?:Money|Balance|Coins?):\s*\$?([0-9,]+)/i);
                if (moneyMatch) status.money = `$${moneyMatch[1]}`;

                const playtimeMatch = clean.match(/(?:Playtime|Time Played|Play Time):\s*([^\n\\,]+)/i);
                if (playtimeMatch) status.playtime = playtimeMatch[1].trim();

                const shardsMatch = clean.match(/(?:Donut )?Shards?:\s*([0-9,]+)/i);
                if (shardsMatch) status.shards = shardsMatch[1];

                const rankMatch = clean.match(/Rank:\s*([^\n\\,]+)/i);
                if (rankMatch) status.rank = rankMatch[1].trim();
            });

            bot.on('error', (err) => {
                status.status = "Unknown";
                status.reason = `Connection Error: ${err.message}`;
                finish(status);
            });

            bot.on('kicked', (reason) => {
                try {
                    const kickReason = JSON.parse(reason);
                    if (kickReason.text) status.reason = kickReason.text;
                    else if (kickReason.extra) status.reason = kickReason.extra.map(e => e.text).join(' ');
                    else status.reason = reason.substring(0, 100);
                } catch (e) {
                    status.reason = reason.replace(/§./g, '').substring(0, 100);
                }

                if (status.reason.includes("You are already online, try restarting your game.")) {
                    status.status = "Unbanned";
                } else {
                    status.status = "Banned";
                }
                finish(status);
            });

            setTimeout(() => {
                if (!resolved) {
                    status.status = "Unknown";
                    status.reason = "Connection Timeout";
                    finish(status);
                }
            }, 10000);
        });
    }

    async checkAccount(email, password) {
        this.cookies.clear();
        console.log(`[Checker] Starting check for ${email}`);
        try {
            let urlPost, sFTTag;
            for (let i = 0; i < 3; i++) {
                console.log(`[Checker] Getting Login URL (Attempt ${i + 1})`);
                ({ urlPost, sFTTag } = await this.getUrlPostSFTTag());
                if (urlPost && sFTTag) break;
                await new Promise(r => setTimeout(r, 1000));
            }

            if (!urlPost || !sFTTag) {
                console.error("[Checker] Failed to get Login URL (Connection/Rate Limit)");
                return { success: false, message: "Failed to get Login URL (Connection/Rate Limit)" };
            }

            console.log("[Checker] Got Login URL, attempting Xbox RPS Login");
            const { token, error } = await this.getXboxRps(email, password, urlPost, sFTTag);

            if (token === "2FA") {
                console.log("[Checker] 2FA Required for account");
                return { success: false, message: "2FA / Email Verification Required" };
            }
            if (!token) {
                console.error(`[Checker] Login failed: ${error || "Invalid Credentials"}`);
                return { success: false, message: error || "Invalid Credentials" };
            }

            console.log("[Checker] Got Xbox RPS token, authenticate with Xbox Live");
            const xboxLogin = await axios.post('https://user.auth.xboxlive.com/user/authenticate', {
                Properties: { AuthMethod: "RPS", SiteName: "user.auth.xboxlive.com", RpsTicket: token },
                RelyingParty: "http://auth.xboxlive.com",
                TokenType: "JWT"
            }, {
                httpsAgent,
                headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' }
            });

            const xboxToken = xboxLogin.data.Token;
            const uhs = xboxLogin.data.DisplayClaims.xui[0].uhs;
            console.log("[Checker] Xbox Live Auth success, uhs:", uhs);

            console.log("[Checker] Authorizing with XSTS");
            const xstsResponse = await axios.post('https://xsts.auth.xboxlive.com/xsts/authorize', {
                Properties: { SandboxId: "RETAIL", UserTokens: [xboxToken] },
                RelyingParty: "rp://api.minecraftservices.com/",
                TokenType: "JWT"
            }, {
                httpsAgent,
                validateStatus: null,
                headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' }
            });

            if (xstsResponse.status !== 200) {
                console.error(`[Checker] XSTS Error ${xstsResponse.status}:`, JSON.stringify(xstsResponse.data));
                return { success: false, message: `XSTS Authorization Failed (${xstsResponse.status})` };
            }

            const xstsToken = xstsResponse.data.Token;
            console.log("[Checker] XSTS success, fetching MC Token");
            const mcToken = await this.getMcToken(uhs, xstsToken);

            if (!mcToken) {
                console.error("[Checker] Failed to get Minecraft Token");
                return { success: false, message: "Failed to get Minecraft Token" };
            }

            console.log("[Checker] MC Token obtained, checking ownership and profile");
            const ownership = await this.checkOwnership(mcToken);
            const { id: uuidStr, name: username, capes } = await this.getProfile(mcToken);

            console.log(`[Checker] Profile: ${username} (${uuidStr}), Ownership: ${ownership}`);

            if (!username) {
                return { success: true, email, password, type: ownership, username: "N/A" };
            }

            console.log("[Checker] Fetching Hypixel stats...");
            const hypixelStats = await this.checkHypixelStats(username);

            console.log("[Checker] Connecting to Hypixel via Mineflayer...");
            const hypixelBan = await this.checkMineflayerBan('hypixel.net', username, mcToken, uuidStr);
            console.log(`[Checker] Hypixel Ban Status: ${hypixelBan.status}`);

            console.log("[Checker] Connecting to Donut SMP via Mineflayer...");
            const donutStatus = await this.checkDonutStats(username, mcToken, uuidStr);
            console.log(`[Checker] Donut Status: ${donutStatus.status}`);

            return {
                success: true,
                email,
                password,
                username,
                uuid: uuidStr,
                type: ownership,
                capes: capes.map(c => c.alias),
                hypixel: hypixelStats,
                hypixel_ban: hypixelBan,
                donut: donutStatus
            };

        } catch (error) {
            console.error(`[Checker] Fatal Error: ${error.message}`);
            if (error.response) {
                console.error(`[Checker] Response data: ${JSON.stringify(error.response.data)}`);
            }
            return { success: false, message: `Error during checks: ${error.message}` };
        }
    }
}

module.exports = WarvChecker;
